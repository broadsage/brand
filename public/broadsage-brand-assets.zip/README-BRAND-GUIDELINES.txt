========================================================================
BROADSAGE OFFICIAL BRAND ASSETS & PRESS KIT (v1.0.0)
Broad Vision, Sage Guidance — Open to Everyone
https://brand.broadsage.com
========================================================================

1. OFFICIAL NAMING CONVENTION & PRESS INQUIRIES
   - Correct:   Broadsage (one word, title case in prose)
   - Correct:   BROADSAGE (uppercase in official wordmark lockup)
   - Incorrect: Broad Sage (never separated)
   - Incorrect: BroadSage (never camelCase)
   - Incorrect: broadsage (never lowercase in formal text)
   - Press & Media Inquiries: brand@broadsage.com

2. OFFICIAL PRESS BOILERPLATE (PRE-APPROVED COPY)
   [One-Sentence Elevator Pitch]
   "Broadsage unites open-source innovation with hardened enterprise platform engineering — Broad Vision, Sage Guidance, Open to Everyone."

   [50-Word Standard Boilerplate]
   "Broadsage is an open-source enterprise platform bridging cloud-native innovation and agentic AI with hardened, production-grade architectures. Featuring Ollie the Sage Owl, Broadsage champions the open enterprise foundation with calm, authoritative architectural guidance and zero vendor lock-in."

3. CORE COLOR PALETTE (Palette 3)
   - Midnight Navy (Canvas Base):     #0A1128  | rgb(10, 17, 40)
   - Obsidian Slate (Deep Canvas):    #050814  | rgb(5, 8, 20)
   - Solar Gold (Sage Beacon):        #F59E0B  | rgb(245, 158, 11)  | Pantone 130 C
   - Solar Light Gold (Iris Glint):   #FCD34D  | rgb(252, 211, 77)  | Pantone 120 C
   - Cloud Azure (Broad Vision):      #0284C7  | rgb(2, 132, 199)   | Pantone 2174 C
   - Crisp Snow White (Headings):     #FFFFFF  | rgb(255, 255, 255)

4. GROUND & CONTRAST RULES
   - Native Dark Grounds: Use primary two-tone mark (#FFFFFF + #F59E0B).
   - Crisp White Grounds:  Use dark wordmark (#0A1128 + #D97706).
   - Solid Accent Grounds: When printing on solid Solar Gold Amber (#F59E0B) or Cloud Azure,
     use the solid Midnight Navy (#0A1128) monochrome lockup. Never use the multi-color mark on amber.

5. TYPOGRAPHY STACKS
   - UI & Prose:  -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif
   - Code & CLI:  ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace

6. FOLDER CONTENTS
   /logos/vector-svg/   -> Infinite-resolution SVG vector marks
   /logos/high-dpi-png/ -> Transparent PNGs (1024px & 2048px)
   /banners/vector-svg/   -> GitHub hero and repository status badges (SVG)
   /banners/high-dpi-png/ -> Platform-native raster banners and status badges
   /tokens/             -> CSS variables, Tailwind config, and JSON tokens

For complete live guidelines, token matrix, and vector canvas tools, visit:
https://brand.broadsage.com
